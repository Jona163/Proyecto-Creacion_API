package com.proyectointegrador.grupo3401_servicio;

import com.proyectointegrador.grupo3401_repo.Grupo3401_repositorio;
import com.proyectointegrador.modelo.AgendaGrupo3401;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class Grupo3401_implementacion implements Grupo3401_servicio{
    @Autowired
    Grupo3401_repositorio grupo3401Repositorio;

    @Override
    public ArrayList<AgendaGrupo3401> mostrarTodosAlumnos() {
        return (ArrayList<AgendaGrupo3401>) grupo3401Repositorio.findAll();
    }

    @Override
    public Optional<AgendaGrupo3401> mostrarAlumnoPorId(long id) {

        return grupo3401Repositorio.findById(id);
    }

    @Override
    public AgendaGrupo3401 guardarAlumno(AgendaGrupo3401 alumno) {
        return grupo3401Repositorio.save(alumno);
    }

    @Override
    public boolean borrarAlumnoPorId(long id) {
        Optional<AgendaGrupo3401> juegoOptional = grupo3401Repositorio.findById(id);
        if (juegoOptional.isPresent()) {
            grupo3401Repositorio.delete(juegoOptional.get());
            return true;
        }
        return false;
    }

    @Override
    public boolean actuAlumno(long id, AgendaGrupo3401 juegoActualizado) {
        Optional<AgendaGrupo3401> juegoOptional = grupo3401Repositorio.findById(id);
        if (juegoOptional.isPresent()) {
            AgendaGrupo3401 juegoExistente = juegoOptional.get();

            // Actualiza los campos necesarios del juego existente con los valores del juego actualizado
            juegoExistente.setNombre(juegoActualizado.getNombre());
            juegoExistente.setGustos(juegoActualizado.getGustos());
            juegoExistente.setFechaCumple(juegoActualizado.getFechaCumple());
            // ...

            // Guarda los cambios en la base de datos
            grupo3401Repositorio.save(juegoExistente);

            return true;
        }
        return false;
    }
}
