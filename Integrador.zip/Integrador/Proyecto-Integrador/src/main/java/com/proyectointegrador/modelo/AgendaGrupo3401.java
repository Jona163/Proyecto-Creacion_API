package com.proyectointegrador.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AgendaGrupo3401 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nombre;
    private String fechaCumple;
    private String gustos;

    public AgendaGrupo3401() {
    }

    public AgendaGrupo3401(String nombre, String fechaCumple, String gustos) {
        this.nombre = nombre;
        this.fechaCumple = fechaCumple;
        this.gustos = gustos;
    }

    public AgendaGrupo3401(long id, String nombre, String fechaCumple, String gustos) {
        this.id = id;
        this.nombre = nombre;
        this.fechaCumple = fechaCumple;
        this.gustos = gustos;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaCumple() {
        return fechaCumple;
    }

    public void setFechaCumple(String fechaCumple) {
        this.fechaCumple = fechaCumple;
    }

    public String getGustos() {
        return gustos;
    }

    public void setGustos(String gustos) {
        this.gustos = gustos;
    }


}
