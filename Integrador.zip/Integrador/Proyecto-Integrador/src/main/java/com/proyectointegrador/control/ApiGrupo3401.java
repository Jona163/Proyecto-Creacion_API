package com.proyectointegrador.control;

import com.proyectointegrador.grupo3401_repo.Grupo3401_repositorio;
import com.proyectointegrador.grupo3401_servicio.Grupo3401_servicio;
import com.proyectointegrador.modelo.AgendaGrupo3401;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@RestController
@RequestMapping("api") //Path o ruta de acceso
public class ApiGrupo3401 {

    @Autowired
    Grupo3401_servicio grupo3401Servicio;

    @GetMapping("/prueba")
    public String prueba(){
        return "Hola Mundo desde Spinng Java";
    }

    @GetMapping("/mostrar-todos")
    public ArrayList<AgendaGrupo3401> mostrarTodosAlumn(){
        return grupo3401Servicio.mostrarTodosAlumnos();
    }

    @PostMapping("/guardar")
    public AgendaGrupo3401 guardarAlumno(@RequestBody AgendaGrupo3401 alumn){
        return grupo3401Servicio.guardarAlumno(alumn);
    }

    @DeleteMapping("/borrar/{id}")
    public ResponseEntity<String> borrarJuego(@PathVariable long id) {
        boolean borrado = grupo3401Servicio.borrarAlumnoPorId(id);
        if (borrado) {
            return ResponseEntity.ok("Juego eliminado correctamente.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el juego con el ID especificado.");
        }
    }

    @GetMapping("/findbyid/{id}")
    public Optional<AgendaGrupo3401> mostrarJuegoPorId(@PathVariable long id) {
        Optional<AgendaGrupo3401> juegoOptional = grupo3401Servicio.mostrarAlumnoPorId(id);
        if (juegoOptional.isPresent()) {
            return grupo3401Servicio.mostrarAlumnoPorId(id);
        } else {
            return Optional.empty();
        }
    }

    @PostMapping("/actualizar/{id}")
    public ResponseEntity<AgendaGrupo3401> actuAlumno(@PathVariable long id, @RequestBody AgendaGrupo3401 juegoActualizado) {
        Optional<AgendaGrupo3401> juegoOptional = grupo3401Servicio.mostrarAlumnoPorId(id);
        if (juegoOptional.isPresent()) {
            AgendaGrupo3401 juegoExistente = juegoOptional.get();
            // Actualiza los campos necesarios del juego existente con los valores del juego actualizado
            juegoExistente.setNombre(juegoActualizado.getNombre());
            juegoExistente.setGustos(juegoActualizado.getGustos());
            juegoExistente.setFechaCumple(juegoActualizado.getFechaCumple());
            // ...

            // Guarda los cambios en la base de datos
            AgendaGrupo3401 juegoActualizadoGuardado = grupo3401Servicio.guardarAlumno(juegoExistente);
            return ResponseEntity.ok(juegoActualizadoGuardado);
        } else {
            // Maneja el caso en el que el juego no existe
            return ResponseEntity.notFound().build();
        }
    }
}
