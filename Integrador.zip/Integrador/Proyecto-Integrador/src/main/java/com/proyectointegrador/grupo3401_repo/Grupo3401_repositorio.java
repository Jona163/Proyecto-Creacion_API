package com.proyectointegrador.grupo3401_repo;
import com.proyectointegrador.modelo.AgendaGrupo3401;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Grupo3401_repositorio extends CrudRepository<AgendaGrupo3401, Long>{
}
