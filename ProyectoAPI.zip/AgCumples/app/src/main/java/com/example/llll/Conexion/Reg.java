package com.example.llll.Conexion;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.VolleyError;
import com.example.llll.Agenda;
import com.example.llll.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

public class Reg extends AppCompatActivity {

    private TextInputLayout idd;

    private Button bus;

    private Button del;

    private Button vol;

    private AgendaClient agendaClient;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendareg);
        idd = findViewById(R.id.txid);
        bus = findViewById(R.id.btnBuscar);
        del = findViewById(R.id.btnBorrar);
        TextView list = findViewById(R.id.txtre);
        vol = findViewById(R.id.btnvol);

        bus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agendaClient = new AgendaClient(Reg.this);
                try {
                    int id = Integer.parseInt(idd.getEditText().getText().toString());
                    agendaClient.findId(id, new AgendaClient.ApiResponseCallback() {
                        @Override
                        public void onSuccess(JSONObject response) {
                            try {
                                JSONObject jsonResponse = new JSONObject(response.toString());
                                int iden = jsonResponse.getInt("id");
                                String nombre = jsonResponse.getString("nombre");
                                String fecha = jsonResponse.getString("fechaCumple");
                                String gustos = jsonResponse.getString("gustos");

                                String data = "ID : " + iden + "\nNombre: " + nombre +
                                        "\nFecha Cumple: " + fecha + "\nGustos: " + gustos;
                                list.setText(data);
                            }catch (JSONException e) {
                                Toast.makeText(Reg.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onError(VolleyError error) {
                            list.setText(null);
                            Toast.makeText(Reg.this, "NO SE ENCONTRO EL REGISTRO", Toast.LENGTH_SHORT).show();
                        }
                    });
                }catch (NumberFormatException e){
                    Toast.makeText(Reg.this, "Ingresa Un Valor valido", Toast.LENGTH_SHORT).show();
                }
            }
        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agendaClient = new AgendaClient(Reg.this);
                try {
                    int id = Integer.parseInt(idd.getEditText().getText().toString());
                    agendaClient.delete(id, new AgendaClient.ApiResponseCallback() {
                        @Override
                        public void onSuccess(JSONObject response) {
                            Toast.makeText(Reg.this, "BORRADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onError(VolleyError error) {
                            Toast.makeText(Reg.this, "NO SE PUDO BORRAR", Toast.LENGTH_SHORT).show();
                        }
                    });
                }catch (NumberFormatException e){
                    Toast.makeText(Reg.this, "Ingresa Un Valor valido", Toast.LENGTH_SHORT).show();
                }
            }
        });

        vol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent en = new Intent(Reg.this, Agenda.class);
                        startActivity(en);
                        finish();
                    }
                }, 500);
            }
        });
    }
}
