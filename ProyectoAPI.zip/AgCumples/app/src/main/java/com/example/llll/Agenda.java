package com.example.llll;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.VolleyError;
import com.example.llll.Conexion.AgendaClient;
import com.example.llll.Conexion.Reg;
import com.example.llll.modelo.Actualizar;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Agenda extends AppCompatActivity {

    private TextInputLayout nom;
    private TextInputLayout fecha;
    private TextInputLayout gus;
    private Button guardar;

    private Button mostrar;

    private AgendaClient agendaClient;

    private Button ac;

    private Button op;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda1);
        nom = findViewById(R.id.Nombre);
        fecha = findViewById(R.id.FechaCumple);
        gus = findViewById(R.id.Gustos);
        guardar = findViewById(R.id.btnAgregar);
        mostrar = findViewById(R.id.button2);
        ListView listView = findViewById(R.id.listView);
        ac = findViewById(R.id.btac);
        op = findViewById(R.id.opc2);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agendaClient = new AgendaClient(Agenda.this);
                try {
                    String nombre = nom.getEditText().getText().toString();
                    String fec = fecha.getEditText().getText().toString();
                    String gustos = gus.getEditText().getText().toString();

                    if (nombre.isEmpty()){
                        Toast.makeText(Agenda.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    }else if (fec.isEmpty()){
                        Toast.makeText(Agenda.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    } else if (gustos.isEmpty()){
                        Toast.makeText(Agenda.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    }

                    JSONObject nuevoalumno = new JSONObject();

                    nuevoalumno.put("nombre", nombre);
                    nuevoalumno.put("fechaCumple", fec);
                    nuevoalumno.put("gustos", gustos);

                    agendaClient.agregar(nuevoalumno, new AgendaClient.ApiResponseCallback() {
                        @Override
                        public void onSuccess(JSONObject response) {
                            Toast.makeText(Agenda.this, "AGREGADO CORRECTAMNETE", Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onError(VolleyError error) {
                            Toast.makeText(Agenda.this, error.toString(), Toast.LENGTH_LONG).show();
                        }
                    });

                }catch (JSONException e) {
                    Toast.makeText(Agenda.this, "ERROR", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agendaClient = new AgendaClient(Agenda.this);
                agendaClient.mostrar(new AgendaClient.ApiResponseCallback2() {
                    @Override
                    public void onSuccess(JSONArray response) {
                        try {
                            StringBuilder data = new StringBuilder();

                            if (response.length() == 0) {
                                // No hay registros disponibles
                                data.append("No hay registros disponibles");
                            } else {
                                for (int i = 0; i < response.length(); i++) {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    // Verificar si los campos en el objeto JSON están vacíos
                                    if (!jsonObject.isNull("id") && !jsonObject.isNull("nombre")
                                            && !jsonObject.isNull("fechaCumple") && !jsonObject.isNull("gustos")) {

                                        // Obtener los valores de los campos en cada objeto JSON
                                        Long id = jsonObject.getLong("id");
                                        String nombre = jsonObject.getString("nombre");
                                        String fecha = jsonObject.getString("fechaCumple");
                                        String gus = jsonObject.getString("gustos");

                                        // Construir la cadena de texto para cada registro
                                        String recordData = "ID: " + id + "\nNombre: " + nombre +
                                                "\nFecha Cumple: " + fecha + "\nGustos: " + gus;

                                        // Agregar el registro a la cadena de texto general
                                        data.append(recordData).append("\n\n");
                                    }
                                }
                            }

                            // Verificar si no se encontraron registros válidos
                            if (data.length() == 0) {
                                data.append("No se encontraron registros válidos");
                            }

                            // Asigna el texto al TextView
                            String[] records = data.toString().split("\n\n");

                            ArrayAdapter<String> adapter = new ArrayAdapter<>(Agenda.this, android.R.layout.simple_list_item_1, records);

                            listView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Agenda.this, "Error al procesar la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onError(VolleyError error) {
                        Toast.makeText(Agenda.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent en = new Intent(Agenda.this, Actualizar.class);
                        startActivity(en);
                        finish();
                    }
                }, 500);
            }
        });

        op.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent en = new Intent(Agenda.this, Reg.class);
                        startActivity(en);
                        finish();
                    }
                }, 500);
            }
        });
    }
}
