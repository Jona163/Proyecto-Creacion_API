package com.example.llll.modelo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.VolleyError;
import com.example.llll.Agenda;
import com.example.llll.Conexion.AgendaClient;
import com.example.llll.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.PhantomReference;

public class Actualizar extends AppCompatActivity {

    private TextInputLayout nom;
    private TextInputLayout fecha;
    private TextInputLayout gus;

    private TextInputLayout id;
    private Button ac;

    private Button vol;

    private AgendaClient agendaClient;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actua);
        nom = findViewById(R.id.Nombre);
        fecha = findViewById(R.id.FechaCumple);
        gus = findViewById(R.id.Gustos);
        ac = findViewById(R.id.ac);
        id = findViewById(R.id.id);
        vol = findViewById(R.id.button);

        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agendaClient = new AgendaClient(Actualizar.this);
                int idd;
                try {
                    idd = Integer.parseInt(id.getEditText().getText().toString());
                    String nombre = nom.getEditText().getText().toString();
                    String fec = fecha.getEditText().getText().toString();
                    String gustos = gus.getEditText().getText().toString();

                    if (nombre.isEmpty()){
                        Toast.makeText(Actualizar.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    }else if (fec.isEmpty()){
                        Toast.makeText(Actualizar.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    } else if (gustos.isEmpty()){
                        Toast.makeText(Actualizar.this, "INGRESE UN VALOR VALIDO", Toast.LENGTH_LONG).show();
                    }

                    JSONObject acalum = new JSONObject();

                    acalum.put("nombre", nombre);
                    acalum.put("fechaCumple", fec);
                    acalum.put("gustos", gustos);

                    agendaClient.actualizarAlumno(idd, acalum, new AgendaClient.ApiResponseCallback() {
                        @Override
                        public void onSuccess(JSONObject response) {
                            Toast.makeText(Actualizar.this, "ACTUALIZADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onError(VolleyError error) {
                            Toast.makeText(Actualizar.this, error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }catch (JSONException e) {
                    Toast.makeText(Actualizar.this, "ERROR", Toast.LENGTH_SHORT).show();
                }catch (NumberFormatException e) {
                    Toast.makeText(Actualizar.this, "Ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        vol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent e = new Intent(Actualizar.this, Agenda.class);
                        startActivity(e);
                        finish();
                    }
                }, 2500);
            }
        });
    }
}
