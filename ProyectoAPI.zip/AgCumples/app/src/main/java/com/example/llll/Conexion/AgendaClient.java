package com.example.llll.Conexion;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class AgendaClient {

    private static AgendaClient instance;

    private RequestQueue requestQueue;

    public AgendaClient(Context context){
        requestQueue = Volley.newRequestQueue(context.getApplicationContext());
    }

    public static synchronized AgendaClient getInstance(Context context){
        if(instance == null){
            instance = new AgendaClient(context);
        }
        return instance;
    }

    public RequestQueue getRequestQueue(){return requestQueue;}

    public void findId(final int id, final ApiResponseCallback callback){

        String url = "http://192.168.8.9:8080/api/findbyid/" + id;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                callback.onError(error);
            }
        });
        requestQueue.add(request);
    }

    public void agregar(final JSONObject alumno, final ApiResponseCallback callback){
        String url = "http://192.168.8.9:8080/api/guardar";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, alumno,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        callback.onSuccess(response);
                    }
                },
                new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    callback.onError(error);
                }
        });
        requestQueue.add(request);
    }

    public void mostrar(final ApiResponseCallback2 callback) {
        String url = "http://192.168.8.9:8080/api/mostrar-todos";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Procesa la respuesta JSON y llama al callback
                        callback.onSuccess(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Llama al callback con el error
                        callback.onError(error);
                    }
                });

        // Agrega la solicitud a la cola de solicitudes de Volley
        requestQueue.add(request);
    }

    public void actualizarAlumno(final int id, final JSONObject valoresActualizados, final ApiResponseCallback callback) {
        String url = "http://192.168.8.9:8080/api/actualizar/" + id;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, valoresActualizados,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // La actualización se ha realizado correctamente
                        // Puedes realizar las acciones necesarias después de la actualización
                        callback.onSuccess(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Manejar el error de la solicitud
                        callback.onError(error);
                    }
                });

        // Agregar la solicitud a la cola de solicitudes de Volley
        requestQueue.add(request);
    }

    public void delete(final int id, final ApiResponseCallback callback) {
        String url = "http://192.168.8.9:8080/api/borrar/" + id;
        StringRequest request = new StringRequest(Request.Method.DELETE, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Llama al callback con una respuesta vacía
                        callback.onSuccess(null);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Llama al callback con el error
                        callback.onError(error);
                    }
                });

        // Agrega la solicitud a la cola de solicitudes de Volley
        requestQueue.add(request);
    }

    public interface ApiResponseCallback2 {
        void onSuccess(JSONArray response);

        void onError(VolleyError error);
    }


    public interface ApiResponseCallback{
        void onSuccess(JSONObject response);

        void onError(VolleyError error);
    }
}
